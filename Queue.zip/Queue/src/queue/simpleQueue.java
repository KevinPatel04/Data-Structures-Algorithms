package queue;
import java.util.*;

public class simpleQueue {

    int queue[];
    int front=-1,rear=-1;
    int size;
    public static void main(String[] args) {
        int i;
        int num=220000;
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter number of customer expected today :: ");
        simpleQueue q=new simpleQueue();
        q.size=sc.nextInt();
        q.queue=new int[q.size];
        while(true){
            System.out.print("Enter 1) Answer the Next Call | 2) Put Call on Hold | 0) Exit :: ");
            i=sc.nextInt();
            switch(i){
                case 1:
                    i=q.delete();
                    if(i!=-1){
                        System.out.println("Last Call Answered :: "+i);
                    }
                    q.display();
                    break;
                case 2:
                    q.insert(num);
                    System.out.println("Call on Hold :: "+num);
                    q.display();
                    num++;
                    break;
                case 0:
                    System.out.println("Service Closed...");
                    System.out.println("\nKEVIN PATEL\n17CE074");
                    System.exit(0);
            }
        }
    }
    
    void insert(int x){
        if(rear>=size-1){
            System.out.println("Queue is Full...");
            return;
        }
        rear++;
        queue[rear]=x;
        if(front==-1){
            front=0;
        }
    }
    
    int delete(){
        if(rear==-1){
            System.out.println("Queue is Empty...");
            return -1;
        }
        int data=queue[rear];
        if(rear==front){
            front=rear=-1;
        }else{
            front++;
        }
        return data;
    }
    
    void display(){
        System.out.print("Queue:: [ ");
        if(front!=-1){
            for(int i=front;i<=rear;i++){
                System.out.print(queue[i]+" ");
            }
        }
        System.out.println("]   Front <--> Rear\n");
    }
    
    
    
}
