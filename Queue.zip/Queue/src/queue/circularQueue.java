package queue;
import java.util.*;

public class circularQueue{
    
    int cirQueue[];
    int front=-1,rear=-1;
    int size;
    
    public static void  main(String[] args){
        circularQueue cq=new circularQueue();
        cq.size=5;
        cq.cirQueue=new int[cq.size];
        System.out.println("cirInsert( 10 );");
        cq.cirInsert(10);
        cq.cirDisplay();
        System.out.println("cirInsert( 50 );");
        cq.cirInsert(50);
        cq.cirDisplay();
        System.out.println("cirInsert( 40 );");
        cq.cirInsert(40);
        cq.cirDisplay();
        System.out.println("cirInsert( 80 );");
        cq.cirInsert(80);
        cq.cirDisplay();
        System.out.println("cirDelete( "+cq.cirDelete()+" );");
        cq.cirDisplay();
        System.out.println("cirInsert( 200 );");
        cq.cirInsert(200);
        cq.cirDisplay();
        System.out.println("cirInsert( 70 );");
        cq.cirInsert(70);
        cq.cirDisplay();
        System.out.println("cirInsert( 150 );");
        cq.cirInsert(150);
        cq.cirDisplay();
        System.out.println("cirDelete( "+cq.cirDelete()+" );");
        cq.cirDisplay();
        System.out.println("cirDelete( "+cq.cirDelete()+" );");
        cq.cirDisplay();
        System.out.println("cirDelete( "+cq.cirDelete()+" );");
        cq.cirDisplay();

        System.out.println("KEVIN PATEL\n17CE074");
    }
    
    void cirInsert(int x){
        
        if((rear>=size-1 && front==0) || (front==rear+1)){
            System.out.println("Queue is Full...");
            return;
        }
        rear++;
        if(rear==size){
            rear=0;
        }    
        cirQueue[rear]=x;
        if(front==-1){
            front=0;
        }
    
    }
    
    int cirDelete(){
        if(rear==-1 && front==-1){
            System.out.println("Queue is Empty...");
            return -1;
        }
        int data=cirQueue[rear];
        front++;
        if(size==front){
            front=0;
        }
        if(front==rear){
            front=rear=-1;
        }
        return data;
    }
    
    void cirDisplay(){
        System.out.print("Queue:: [ ");
        if(front!=-1 && rear!=-1){
            if(front<=rear)
                for(int i=front;i<=rear;i++){
                    System.out.print(cirQueue[i]+" ");
                }
            else{
                for(int i=front;i<size;i++){
                    System.out.print(cirQueue[i]+" ");
                }
                for(int i=0;i<=rear;i++){
                    System.out.print(cirQueue[i]+" ");
                }
            }
        }
        System.out.println("]   Front <--> Rear\n");
    }
    
    
    
}
