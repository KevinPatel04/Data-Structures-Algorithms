package infixtopostfix;
import java.util.*;
import java.lang.Character;

public class InfixToPostfix {
    char stack[];
    int size;
    int top=-1;
    
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Infix expression:: ");
        String exp = sc.next();
        InfixToPostfix post = new InfixToPostfix();
        System.out.println("Infix:: "+exp);
        System.out.println("PostFix:: "+post.InfixtoPostfix(exp));
        System.out.println("\nKEVIN PATEL\n17CE074");
    }
    
    
    
    int precedence(char ch){
        if(ch == '+' | ch=='-'){
            return 1;
        }else if(ch=='*' | ch=='/' | ch=='%'){
            return 3;
        }else if(ch=='^'){
            return 6;
        }else if(Character.isLetter(ch) | Character.isDigit(ch)){
            return 7;           
        }else if(ch=='('){
            return 9;
        }
        
        return 0;
    }
    int getRank(char ch){
        if(ch== '^' | ch == '+' | ch=='-' | ch== '*' | ch== '/' | ch== '%'){
            return -1;
        }else if(Character.isLetter(ch) | Character.isDigit(ch)){
            return 1;           
        }
        return 0;
    }
    void push(char ch){
        if(top>=size-1){
            System.out.println("Stack Overflow");
            return;
        }else{
            top=top+1;
            stack[top]=ch;
        }
    }
    
    char pop(){
        if(top==-1){
            System.out.println("Stack Underflow");
            return '$';
        }else{
            return stack[top--];
        }
    }
    
    int stackPrecedence(char ch){
        if(ch == '+' | ch=='-'){
            return 2;
        }else if(ch=='*' | ch=='/' | ch=='%'){
            return 4;
        }else if(ch=='^'){
            return 5;
        }else if(Character.isLetter(ch) | Character.isDigit(ch)){
            return 8;           
        }else if(ch=='('){
            return 0;
        }
        return 0;
    }
    
    public String InfixtoPostfix(String exp){
        exp="("+exp+")";
        int rank=0;
        char next;
        size=exp.length();
        String ans="";
        stack=new char[exp.length()];
        next= exp.charAt(0);
        push(next);
        int i=1;
        next=exp.charAt(i);
        while(true){
            if(top==-1){
                System.out.println("Invalid...0");
                System.exit(0);
            }
            
            while(precedence(next)<stackPrecedence(stack[top])){
                char temp=pop();
                ans=ans+temp;
                rank+=getRank(temp);
                if(rank==0){
                    System.out.println("Invalid...1");
                    System.exit(0);
                }
            }
            if(precedence(next)!=stackPrecedence(next)){
                push(next);
            }else{
                pop();
            }
            if(i!=size-1){
                i++;
                next=exp.charAt(i);
            }else{
                break;
            }
        }
        if(top!=-1 | rank!=1){
            System.out.println("Invalid...3");
            System.exit(0);
        }
       // System.out.println("Postfix:: "+ans);
        return ans;
    }
    
    
    
}
