package infixtopostfix;
import java.util.*;
import java.lang.*;
public class evaluatePostfix {
    int stack[];
    int size;
    int top=-1;
    public static void main(String[] args){    
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Infix Expresion :: ");
        String post=new String();
        post=sc.next();
        InfixToPostfix inf=new InfixToPostfix();
        post=inf.InfixtoPostfix(post);
        System.out.println("Postfix:: "+post);
        evaluatePostfix e=new evaluatePostfix();
        System.out.println("Ans:: "+e.evaluate(post));
        System.out.println("\nKEVIN PATEL\n17CE074");
    }
    
    int calculate(char ch,int a,int b){
        int ans;
        switch(ch){
            case '+':
                ans=a+b;
                break;
            case '*':
                ans=a*b;
                break;
            case '/':
                ans=a/b;
                break;
            case '%':
                ans=a%b;
                break;
            case '-':
                ans=a-b;
                break;
            case '^':
                ans=(int) Math.pow(a, b);
                break;
            default:
                ans=0;
        }
        return ans;
    }
    
    int evaluate(String post){
        int len=post.length();
        int j=0;
        size=len;
        stack=new int[size]; 
        Scanner sc=new Scanner(System.in);
        //post=new StringBuffer(post).reverse().toString();
        while(j<len){
            char c=post.charAt(j);
            if(Character.isDigit(c)){
                int a=Integer.parseInt(Character.toString(c));
                push(a);
            }else if(Character.isLetter(c)){
                System.out.print("Enter value of \""+c+"\":: ");
                int a=sc.nextInt();
                //int a=Integer.parseInt(Character.toString(c));
                push(a);
            }
            else if(isOp(c)>0){
                int op2=pop();
                int op1=pop();
                push(calculate(c,op1,op2));
            }      
            j++;
        }
        int ans=pop();
        return ans;
    }
    
    int isOp(char ch){
        if(ch == '+' | ch=='-' | ch=='*' | ch=='/' | ch=='%' | ch=='^'){
            return 1;
        }else {
            return 0;           
        }
    }
    
    void push(int ch){
        if(top>=size-1){
            System.out.println("Stack Overflow");
            return;
        }else{
            top=top+1;
            stack[top]=ch;
        }
    }
    
    int pop(){
        if(top==-1){
            System.out.println("Stack Underflow");
            return -1;
        }else{
            return stack[top--];
        }
    }
    
    
    
}
